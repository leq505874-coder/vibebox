/*
 * VIBEBOX — Audio Engine
 * Chỉ chứa logic âm thanh (Web Audio API), không đụng tới DOM.
 * Dễ chuyển sang Android native: mỗi băng = 1 biquad (lowshelf / peaking / highshelf),
 * tương đương android.media.audiofx.Equalizer hoặc một biquad chain tự viết trên Oboe.
 *
 * Đồ thị âm thanh:
 *   <audio> / noise -> input -> [biquad x N] -> preamp -> analyser -> master(volume) -> destination
 *   EQ tắt (bypass):  input -> preamp -> ...
 */
(function (global) {
  'use strict';

  const MIN_F = 32, MAX_F = 16000;
  const GAIN_MIN = -12, GAIN_MAX = 12;
  const MIN_BANDS = 3, MAX_BANDS = 15;

  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  function niceFreq(f) {
    if (f < 100) return Math.round(f);
    if (f < 1000) return Math.round(f / 5) * 5;
    return Math.round(f / 50) * 50;
  }

  /** Tạo n tần số trung tâm, chia đều theo log từ 32 Hz đến 16 kHz. */
  function makeFreqs(n) {
    n = clamp(Math.round(n), MIN_BANDS, MAX_BANDS);
    const out = [];
    for (let i = 0; i < n; i++) {
      out.push(niceFreq(MIN_F * Math.pow(MAX_F / MIN_F, i / (n - 1))));
    }
    return out;
  }

  /** Q của băng peaking sao cho các băng liền kề phủ nhau vừa phải. */
  function bandQ(n) {
    const bw = Math.log2(MAX_F / MIN_F) / (n - 1); // octave giữa 2 băng
    const p = Math.pow(2, bw);
    return clamp(Math.sqrt(p) / (p - 1), 0.5, 4);
  }

  function bandType(i, n) {
    return i === 0 ? 'lowshelf' : i === n - 1 ? 'highshelf' : 'peaking';
  }

  function createFilters(ctx, freqs, gains) {
    const q = bandQ(freqs.length);
    return freqs.map((f, i) => {
      const b = ctx.createBiquadFilter();
      b.type = bandType(i, freqs.length);
      b.frequency.value = f;
      b.Q.value = q;
      b.gain.value = gains[i] || 0;
      return b;
    });
  }

  /** Đáp ứng biên độ (tuyến tính) của cả chuỗi biquad tại các tần số hz. */
  function chainMagnitude(filters, hz) {
    const total = new Float32Array(hz.length).fill(1);
    const mag = new Float32Array(hz.length);
    const phase = new Float32Array(hz.length);
    filters.forEach((f) => {
      f.getFrequencyResponse(hz, mag, phase);
      for (let i = 0; i < hz.length; i++) total[i] *= mag[i];
    });
    return total;
  }

  const toDb = (lin) => 20 * Math.log10(Math.max(lin, 1e-9));

  class AudioEngine {
    constructor() {
      this.AC = global.AudioContext || global.webkitAudioContext || null;
      this.OAC = global.OfflineAudioContext || global.webkitOfflineAudioContext || null;
      this.supported = !!this.AC && typeof global.Audio !== 'undefined';
      this.error = this.supported ? null : 'Trình duyệt không có Web Audio API.';

      this.freqs = makeFreqs(10);
      this.gains = this.freqs.map(() => 0);
      this.enabled = true;
      this.headroom = true;
      this.volume = 0.8;

      this.ctx = null;
      this.filters = [];
      this.noiseOn = false;
      this.objectUrl = null;
      this.audio = this.supported ? new global.Audio() : null;
      if (this.audio) this.audio.preload = 'metadata';
      this._h = {};
    }

    on(evt, fn) { (this._h[evt] = this._h[evt] || []).push(fn); }
    emit(evt, data) { (this._h[evt] || []).forEach((fn) => fn(data)); }

    /** Tạo AudioContext + đồ thị. Gọi sớm được (context ở trạng thái suspended tới khi người dùng bấm Play). */
    init() {
      if (!this.supported) return false;
      if (this.ctx) return true;
      try {
        this.ctx = new this.AC({ latencyHint: 'playback' });
      } catch (e) {
        try { this.ctx = new this.AC(); } catch (e2) {
          this.supported = false; this.error = String(e2.message || e2); return false;
        }
      }
      const ctx = this.ctx;
      this.input = ctx.createGain();
      this.preamp = ctx.createGain();
      this.analyser = ctx.createAnalyser();
      this.analyser.fftSize = 512;
      this.analyser.smoothingTimeConstant = 0.82;
      this.master = ctx.createGain();
      this.master.gain.value = this.volume;
      this.preamp.connect(this.analyser);
      this.analyser.connect(this.master);
      this.master.connect(ctx.destination);

      try {
        this.mediaSource = ctx.createMediaElementSource(this.audio);
        this.mediaSource.connect(this.input);
      } catch (e) {
        this.supported = false; this.error = 'Không gắn được trình phát vào EQ: ' + e.message; return false;
      }

      this.filters = createFilters(ctx, this.freqs, this.gains);
      this._wire();

      ctx.addEventListener('statechange', () => this.emit('status', this.status()));
      ['play', 'pause', 'ended', 'emptied'].forEach((ev) =>
        this.audio.addEventListener(ev, () => this.emit('status', this.status())));
      return true;
    }

    /** Nối lại chuỗi EQ (hoặc bypass). */
    _wire() {
      if (!this.ctx) return;
      this.input.disconnect();
      this.filters.forEach((f) => f.disconnect());
      if (this.enabled && this.filters.length) {
        this.input.connect(this.filters[0]);
        for (let i = 0; i < this.filters.length - 1; i++) this.filters[i].connect(this.filters[i + 1]);
        this.filters[this.filters.length - 1].connect(this.preamp);
      } else {
        this.input.connect(this.preamp);
      }
      this._updatePreamp();
    }

    /** Giảm preamp bằng đúng mức boost lớn nhất của đường cong để tránh clipping. */
    _updatePreamp() {
      if (!this.ctx) return;
      let db = 0;
      if (this.enabled && this.headroom) {
        const r = this.getResponse(256);
        db = -Math.max(0, ...r.db);
      }
      this.preamp.gain.setTargetAtTime(Math.pow(10, db / 20), this.ctx.currentTime, 0.02);
      this.headroomDb = db;
    }

    status() {
      if (!this.supported) return { state: 'unsupported', reason: this.error || 'Không được hỗ trợ' };
      const playing = (this.audio && !this.audio.paused && !this.audio.ended) || this.noiseOn;
      if (!this.enabled) return { state: 'inactive', reason: 'EQ đang tắt (bypass)' };
      if (!playing) return { state: 'inactive', reason: 'EQ bật, đang chờ phát nhạc' };
      if (!this.ctx || this.ctx.state !== 'running') return { state: 'inactive', reason: 'AudioContext chưa chạy' };
      return { state: 'active', reason: 'EQ đang xử lý âm thanh của VIBEBOX' };
    }

    // ---------- EQ ----------
    setBandCount(n, gains) {
      this.freqs = makeFreqs(n);
      this.gains = this.freqs.map((_, i) => clamp(gains && gains[i] != null ? gains[i] : 0, GAIN_MIN, GAIN_MAX));
      if (this.ctx) {
        this.filters.forEach((f) => f.disconnect());
        this.filters = createFilters(this.ctx, this.freqs, this.gains);
        this._wire();
      }
    }

    setGain(i, db) {
      db = clamp(db, GAIN_MIN, GAIN_MAX);
      this.gains[i] = db;
      if (this.filters[i]) this.filters[i].gain.value = db;
      this._updatePreamp();
    }

    setGains(arr) {
      arr.forEach((g, i) => {
        if (i >= this.gains.length) return;
        this.gains[i] = clamp(g, GAIN_MIN, GAIN_MAX);
        if (this.filters[i]) this.filters[i].gain.value = this.gains[i];
      });
      this._updatePreamp();
    }

    reset() { this.setGains(this.gains.map(() => 0)); }

    setEnabled(on) { this.enabled = !!on; this._wire(); this.emit('status', this.status()); }
    setHeadroom(on) { this.headroom = !!on; this._updatePreamp(); }

    /** Đáp ứng tần số THẬT, tính từ chính các BiquadFilterNode đang xử lý. */
    getResponse(points) {
      points = points || 160;
      const hz = new Float32Array(points);
      for (let i = 0; i < points; i++) hz[i] = 20 * Math.pow(1000, i / (points - 1)); // 20 Hz..20 kHz
      if (!this.ctx || !this.enabled) return { hz, db: Array.from(hz, () => 0) };
      const lin = chainMagnitude(this.filters, hz);
      return { hz, db: Array.from(lin, toDb) };
    }

    // ---------- Phát nhạc ----------
    setVolume(v) {
      this.volume = clamp(v, 0, 1);
      if (this.master) this.master.gain.value = this.volume;
    }

    loadFile(file) {
      if (!this.audio) return;
      if (this.objectUrl) URL.revokeObjectURL(this.objectUrl);
      this.objectUrl = URL.createObjectURL(file);
      this.audio.src = this.objectUrl;
      this.audio.load();
    }

    async play() {
      if (!this.init()) throw new Error(this.error || 'Không khởi tạo được âm thanh');
      if (this.noiseOn) this.stopNoise();
      if (this.ctx.state !== 'running') await this.ctx.resume();
      await this.audio.play();
    }

    pause() { if (this.audio) this.audio.pause(); }
    seek(t) { if (this.audio && isFinite(this.audio.duration)) this.audio.currentTime = clamp(t, 0, this.audio.duration); }

    // ---------- Nhiễu hồng nội bộ để nghe thử EQ không cần file ----------
    _pinkBuffer() {
      if (this._pink) return this._pink;
      const sr = this.ctx.sampleRate, len = sr * 4;
      const buf = this.ctx.createBuffer(1, len, sr);
      const d = buf.getChannelData(0);
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
      for (let i = 0; i < len; i++) {
        const w = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + w * 0.0555179; b1 = 0.99332 * b1 + w * 0.0750759;
        b2 = 0.969 * b2 + w * 0.153852; b3 = 0.8665 * b3 + w * 0.3104856;
        b4 = 0.55 * b4 + w * 0.5329522; b5 = -0.7616 * b5 - w * 0.016898;
        d[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.05;
        b6 = w * 0.115926;
      }
      // làm mượt điểm nối vòng lặp
      const fade = 512;
      for (let i = 0; i < fade; i++) { const k = i / fade; d[i] *= k; d[len - 1 - i] *= k; }
      return (this._pink = buf);
    }

    async startNoise() {
      if (!this.init()) throw new Error(this.error || 'Không khởi tạo được âm thanh');
      this.pause();
      if (this.ctx.state !== 'running') await this.ctx.resume();
      if (this.noiseOn) return;
      this.noiseSrc = this.ctx.createBufferSource();
      this.noiseSrc.buffer = this._pinkBuffer();
      this.noiseSrc.loop = true;
      this.noiseGain = this.ctx.createGain();
      this.noiseGain.gain.value = 0.6;
      this.noiseSrc.connect(this.noiseGain);
      this.noiseGain.connect(this.input);
      this.noiseSrc.start();
      this.noiseOn = true;
      this.emit('status', this.status());
    }

    stopNoise() {
      if (!this.noiseOn) return;
      try { this.noiseSrc.stop(); } catch (e) { /* đã dừng */ }
      this.noiseSrc.disconnect();
      this.noiseGain.disconnect();
      this.noiseOn = false;
      this.emit('status', this.status());
    }

    // ---------- Tự kiểm tra: đo thật bằng render offline ----------
    /**
     * Với mỗi băng: render 1 sóng sin ở tần số tâm băng qua đúng chuỗi biquad hiện tại,
     * đo RMS đầu ra/đầu vào (dB) và so với đáp ứng lý thuyết. Không phụ thuộc UI.
     */
    async selfTest() {
      if (!this.OAC) throw new Error('Trình duyệt không có OfflineAudioContext');
      const sr = 44100, len = Math.round(sr * 0.8);
      const rows = [];
      for (let i = 0; i < this.freqs.length; i++) {
        const f = this.freqs[i];
        const octx = new this.OAC(1, len, sr);
        const src = octx.createBuffer(1, len, sr);
        const d = src.getChannelData(0);
        for (let n = 0; n < len; n++) d[n] = 0.25 * Math.sin(2 * Math.PI * f * n / sr);
        const bs = octx.createBufferSource();
        bs.buffer = src;
        const filters = createFilters(octx, this.freqs, this.gains);
        let node = bs;
        filters.forEach((fl) => { node.connect(fl); node = fl; });
        node.connect(octx.destination);
        bs.start();
        const out = (await octx.startRendering()).getChannelData(0);
        const from = Math.floor(len / 2);
        let sIn = 0, sOut = 0;
        for (let n = from; n < len; n++) { sIn += d[n] * d[n]; sOut += out[n] * out[n]; }
        const measured = 10 * Math.log10(Math.max(sOut, 1e-18) / sIn);
        const theory = toDb(chainMagnitude(filters, new Float32Array([f]))[0]);
        rows.push({ freq: f, setDb: this.gains[i], theoryDb: theory, measuredDb: measured });
      }
      return rows;
    }
  }

  global.Vibebox = Object.assign(global.Vibebox || {}, {
    AudioEngine, makeFreqs, bandQ, bandType, GAIN_MIN, GAIN_MAX, MIN_BANDS, MAX_BANDS,
  });
})(typeof window !== 'undefined' ? window : globalThis);
