/*
 * VIBEBOX — Media controls (Media Session API)
 * Hiện bảng điều khiển nhạc trên thanh thông báo / màn hình khóa / tai nghe:
 * Play, Pause, Trước, Sau, tua. Không đụng DOM hay DSP; app.js truyền hàm vào.
 *
 * Phạm vi: chạy trong Chrome Android và PWA đã cài. WebView của APK (Capacitor)
 * KHÔNG tự hiện thông báo media — cần plugin/service native (xem README).
 */
(function (global) {
  'use strict';

  function supported(nav) {
    nav = nav || global.navigator;
    return !!(nav && nav.mediaSession && typeof global.MediaMetadata !== 'undefined');
  }

  function safeAction(ms, name, fn) {
    try { ms.setActionHandler(name, fn); return true; } catch (e) { return false; }
  }

  /**
   * opts: { audio, getTitle(), onPlay(), onPause(), onPrev(), onNext(), onSeekTo(sec) }
   * Trả về { supported, update() }.
   */
  function attach(opts, nav) {
    nav = nav || global.navigator;
    if (!supported(nav)) return { supported: false, update() {} };
    const ms = nav.mediaSession;
    const audio = opts.audio;

    function updateMetadata() {
      const title = (opts.getTitle && opts.getTitle()) || 'VIBEBOX';
      try {
        ms.metadata = new global.MediaMetadata({
          title: title,
          artist: 'VIBEBOX · EQ',
          album: 'Music Studio Pocket',
          artwork: [
            { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
            { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
          ],
        });
      } catch (e) { /* bỏ qua */ }
    }

    function updatePosition() {
      if (!ms.setPositionState || !audio || !isFinite(audio.duration) || audio.duration <= 0) return;
      try {
        ms.setPositionState({
          duration: audio.duration,
          playbackRate: audio.playbackRate || 1,
          position: Math.min(audio.currentTime || 0, audio.duration),
        });
      } catch (e) { /* bỏ qua */ }
    }

    function updateState() {
      ms.playbackState = audio.paused ? 'paused' : 'playing';
    }

    safeAction(ms, 'play', () => opts.onPlay && opts.onPlay());
    safeAction(ms, 'pause', () => opts.onPause && opts.onPause());
    safeAction(ms, 'previoustrack', () => opts.onPrev && opts.onPrev());
    safeAction(ms, 'nexttrack', () => opts.onNext && opts.onNext());
    safeAction(ms, 'seekto', (d) => { if (opts.onSeekTo && d && isFinite(d.seekTime)) { opts.onSeekTo(d.seekTime); updatePosition(); } });
    safeAction(ms, 'seekbackward', (d) => opts.onSeekTo && opts.onSeekTo(Math.max(0, audio.currentTime - ((d && d.seekOffset) || 10))));
    safeAction(ms, 'seekforward', (d) => opts.onSeekTo && opts.onSeekTo(Math.min(audio.duration || 0, audio.currentTime + ((d && d.seekOffset) || 10))));

    ['loadstart', 'loadedmetadata'].forEach((e) => audio.addEventListener(e, () => { updateMetadata(); updatePosition(); }));
    ['play', 'pause', 'ended', 'emptied'].forEach((e) => audio.addEventListener(e, () => { updateState(); updatePosition(); }));
    ['durationchange', 'seeked', 'ratechange'].forEach((e) => audio.addEventListener(e, updatePosition));

    updateMetadata(); updateState();
    return { supported: true, update() { updateMetadata(); updateState(); updatePosition(); } };
  }

  global.Vibebox = Object.assign(global.Vibebox || {}, { MediaControls: { supported, attach } });
})(typeof window !== 'undefined' ? window : globalThis);
