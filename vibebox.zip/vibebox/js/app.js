/*
 * VIBEBOX — App controller
 * Nối AudioEngine + PresetStore + UI. Không chứa DSP.
 */
(function () {
  'use strict';

  const { AudioEngine, PresetStore, UI, interpolate, presetGains, MIN_BANDS, MAX_BANDS } = window.Vibebox;
  const $ = (id) => document.getElementById(id);

  const engine = new AudioEngine();
  const store = new PresetStore();
  const state = { activePresetId: 'balanced', queue: [], index: -1, seeking: false };
  let spectrum = null;
  let currentTab = 'now';

  // ---------- Khôi phục trạng thái đã lưu ----------
  (function restore() {
    const s = store.loadState();
    if (!s || typeof s !== 'object') return;
    const n = Number.isInteger(s.bandCount) && s.bandCount >= MIN_BANDS && s.bandCount <= MAX_BANDS ? s.bandCount : 10;
    const gains = Array.isArray(s.gains) && s.gains.length === n && s.gains.every(Number.isFinite) ? s.gains : null;
    engine.setBandCount(n, gains);
    engine.enabled = s.enabled !== false;
    engine.headroom = s.headroom !== false;
    if (Number.isFinite(s.volume)) engine.volume = Math.min(1, Math.max(0, s.volume));
    if (typeof s.activePresetId === 'string') state.activePresetId = s.activePresetId;
  })();

  let saveTimer = 0;
  function persist() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => store.saveState({
      enabled: engine.enabled, headroom: engine.headroom, volume: engine.volume,
      bandCount: engine.freqs.length, gains: engine.gains, activePresetId: state.activePresetId,
    }), 150);
  }

  engine.init(); // tạo AudioContext (suspended tới khi bấm Play)

  // ---------- Hiển thị trạng thái ----------
  function refreshStatus() {
    const st = engine.status();
    UI.setStatus($('statusChip'), st);
    $('eqStatusText').textContent = st.reason;
    $('trackState').textContent = playbackText();
    $('playBtn').classList.toggle('playing', isPlaying());
    $('playBtn').setAttribute('aria-label', isPlaying() ? 'Tạm dừng' : 'Phát');
    updateSpectrum();
  }

  function isPlaying() { return engine.supported && engine.audio && !engine.audio.paused && !engine.audio.ended; }
  function playbackText() {
    if (!engine.supported) return 'Không được hỗ trợ';
    if (engine.noiseOn) return 'Đang phát nhiễu hồng thử EQ';
    if (state.index < 0) return 'Chưa chọn file';
    if (engine.audio.error) return 'Lỗi: không giải mã được file này';
    if (isPlaying()) return 'Đang phát';
    if (engine.audio.ended) return 'Đã phát xong';
    return engine.audio.currentTime > 0 ? 'Tạm dừng' : 'Sẵn sàng';
  }

  function updateSpectrum() {
    if (!spectrum) return;
    const want = currentTab === 'now' && (isPlaying() || engine.noiseOn) && !document.hidden;
    if (want) spectrum.start(); else spectrum.stop();
  }

  // ---------- EQ ----------
  const bandsEl = $('bands');
  const curveEl = $('eqCurve');

  function drawEq() { UI.drawCurve(curveEl, engine.getResponse(180), engine.freqs, engine.enabled); }

  function rebuildBands() {
    UI.renderBands(bandsEl, engine.freqs, engine.gains, { onInput: onBandInput });
    UI.updateBandValues(bandsEl, engine.gains);
    document.querySelectorAll('#bandCount button').forEach((b) =>
      b.classList.toggle('active', Number(b.dataset.n) === engine.freqs.length));
    drawEq();
    refreshPresetUi();
  }

  function onBandInput(i, db, fromReset) {
    engine.setGain(i, db);
    state.activePresetId = 'custom';
    UI.updateBandValues(bandsEl, engine.gains);
    drawEq(); refreshPresetUi(); persist();
  }

  function setEnabled(on) {
    engine.setEnabled(on);
    $('eqToggle').checked = on;
    $('eqToggle').setAttribute('aria-checked', on);
    bandsEl.classList.toggle('disabled', !on);
    drawEq(); persist(); refreshStatus();
  }

  $('eqToggle').addEventListener('change', (e) => setEnabled(e.target.checked));
  $('eqReset').addEventListener('click', () => {
    engine.reset(); state.activePresetId = 'balanced';
    UI.updateBandValues(bandsEl, engine.gains); drawEq(); refreshPresetUi(); persist();
    UI.toast('Đã đặt lại EQ về phẳng (0 dB)');
  });

  document.querySelectorAll('#bandCount button').forEach((btn) => btn.addEventListener('click', () => {
    const n = Number(btn.dataset.n);
    if (n === engine.freqs.length) return;
    // giữ nguyên hình dạng đường cong khi đổi số băng
    const pts = engine.freqs.map((f, i) => [f, engine.gains[i]]);
    engine.setBandCount(n, interpolate(pts, window.Vibebox.makeFreqs(n)));
    rebuildBands(); persist();
  }));

  // ---------- Preset ----------
  function applyPreset(id) {
    const p = store.get(id);
    if (!p) return;
    if (p.bandCount && p.bandCount !== engine.freqs.length) engine.setBandCount(p.bandCount);
    engine.setGains(presetGains(p, engine.freqs));
    state.activePresetId = id;
    rebuildBands(); persist();
    UI.toast('Đã áp dụng preset ' + p.name);
  }

  function refreshPresetUi() {
    const p = store.get(state.activePresetId);
    $('activePreset').textContent = p ? p.name : 'Tùy chỉnh';
    const all = store.all();
    UI.renderPresetList($('builtinList'), all.filter((x) => x.builtin), state.activePresetId, { onApply: applyPreset });
    UI.renderPresetList($('userList'), all.filter((x) => !x.builtin), state.activePresetId, {
      onApply: applyPreset,
      onDelete: (id) => {
        if (state.activePresetId === id) state.activePresetId = 'custom';
        store.remove(id); refreshPresetUi(); persist();
        UI.toast('Đã xóa preset');
      },
    });
  }

  $('savePresetForm').addEventListener('submit', (e) => {
    e.preventDefault();
    try {
      const { preset, persisted } = store.saveUser({
        name: $('presetName').value, freqs: engine.freqs, gains: engine.gains,
      });
      state.activePresetId = preset.id;
      $('presetName').value = '';
      refreshPresetUi(); persist();
      UI.toast(persisted ? 'Đã lưu preset "' + preset.name + '"' : 'Đã lưu tạm trong phiên (thiết bị chặn lưu trữ)');
    } catch (err) { UI.toast(err.message); }
  });

  // ---------- Trình phát ----------
  const seek = $('seek');
  const vol = $('volume');
  const audio = engine.audio;

  function loadIndex(i, autoplay) {
    if (i < 0 || i >= state.queue.length) return;
    state.index = i;
    const item = state.queue[i];
    engine.loadFile(item.file);
    $('trackTitle').textContent = item.name;
    seek.value = 0; $('timeCur').textContent = '0:00'; $('timeDur').textContent = '0:00';
    renderQueue(); refreshStatus();
    if (autoplay) play();
  }

  async function play() {
    if (state.index < 0) { UI.toast('Hãy chọn file âm thanh trước'); return; }
    try { await engine.play(); } catch (e) { UI.toast('Không phát được: ' + e.message); }
    refreshStatus();
  }

  $('playBtn').addEventListener('click', () => { if (isPlaying()) engine.pause(); else play(); });
  $('prevBtn').addEventListener('click', () => {
    if (!audio) return;
    if (audio.currentTime > 3 || state.index <= 0) engine.seek(0); else loadIndex(state.index - 1, isPlaying());
  });
  $('nextBtn').addEventListener('click', () => { if (state.index < state.queue.length - 1) loadIndex(state.index + 1, isPlaying()); });

  $('fileInput').addEventListener('change', (e) => {
    const files = Array.from(e.target.files || []).filter((f) => f.type.startsWith('audio/') || /\.(mp3|m4a|aac|wav|flac|ogg|opus|weba)$/i.test(f.name));
    if (!files.length) { UI.toast('Không có file âm thanh hợp lệ'); return; }
    const first = state.queue.length;
    files.forEach((f) => state.queue.push({ name: f.name.replace(/\.[^.]+$/, ''), file: f }));
    loadIndex(first, true);
    e.target.value = '';
  });

  function renderQueue() {
    const ul = $('queue'); ul.innerHTML = '';
    state.queue.forEach((q, i) => {
      const li = document.createElement('li');
      const b = document.createElement('button');
      b.textContent = q.name; b.className = i === state.index ? 'current' : '';
      b.addEventListener('click', () => loadIndex(i, true));
      li.appendChild(b); ul.appendChild(li);
    });
    $('queueWrap').hidden = state.queue.length < 2;
  }

  if (audio) {
    audio.addEventListener('loadedmetadata', () => {
      seek.max = audio.duration; seek.disabled = !isFinite(audio.duration);
      $('timeDur').textContent = UI.formatTime(audio.duration);
    });
    audio.addEventListener('timeupdate', () => {
      if (state.seeking) return;
      seek.value = audio.currentTime; $('timeCur').textContent = UI.formatTime(audio.currentTime);
    });
    audio.addEventListener('ended', () => {
      if (state.index < state.queue.length - 1) loadIndex(state.index + 1, true); else refreshStatus();
    });
    audio.addEventListener('error', () => { if (audio.src) { UI.toast('Không giải mã được file này (codec không được hỗ trợ?)'); refreshStatus(); } });
    ['play', 'pause', 'emptied', 'loadstart'].forEach((ev) => audio.addEventListener(ev, refreshStatus));
  }

  seek.addEventListener('input', () => {
    state.seeking = true;
    $('timeCur').textContent = UI.formatTime(parseFloat(seek.value));
    engine.seek(parseFloat(seek.value));
  });
  seek.addEventListener('change', () => { state.seeking = false; });
  vol.addEventListener('input', () => { engine.setVolume(parseFloat(vol.value)); $('volLabel').textContent = Math.round(engine.volume * 100) + '%'; persist(); });

  // ---------- Cài đặt ----------
  $('headroomToggle').addEventListener('change', (e) => { engine.setHeadroom(e.target.checked); persist(); });

  $('noiseBtn').addEventListener('click', async () => {
    try {
      if (engine.noiseOn) engine.stopNoise(); else await engine.startNoise();
    } catch (e) { UI.toast('Không phát được: ' + e.message); }
    $('noiseBtn').textContent = engine.noiseOn ? 'Dừng nhiễu hồng' : 'Phát nhiễu hồng thử EQ';
    refreshStatus();
  });

  $('selfTestBtn').addEventListener('click', async () => {
    const out = $('selfTestOut');
    out.textContent = 'Đang đo…';
    try { UI.renderSelfTest(out, await engine.selfTest()); }
    catch (e) { out.innerHTML = '<p class="warn">Không chạy được tự kiểm tra: ' + e.message + '</p>'; }
  });

  $('clearBtn').addEventListener('click', () => {
    if (!confirm('Xóa toàn bộ preset đã lưu và cài đặt?')) return;
    store.clearAll(); engine.reset(); engine.setVolume(0.8); vol.value = 0.8;
    $('volLabel').textContent = '80%'; state.activePresetId = 'balanced';
    rebuildBands(); UI.toast('Đã xóa dữ liệu đã lưu');
  });

  function renderCapabilities() {
    const rows = [
      ['Web Audio API', engine.supported ? 'Có' : 'Không (' + engine.error + ')', engine.supported],
      ['Trạng thái AudioContext', engine.ctx ? engine.ctx.state : 'chưa tạo', !!engine.ctx],
      ['Sample rate', engine.ctx ? engine.ctx.sampleRate + ' Hz' : '—', !!engine.ctx],
      ['Render offline (tự kiểm tra)', engine.OAC ? 'Có' : 'Không', !!engine.OAC],
      ['Lưu preset (localStorage)', store.available ? 'Có' : 'Bị chặn — chỉ lưu trong phiên', store.available],
      ['Điều khiển trên thông báo (Media Session)',
        window.Vibebox.MediaControls && window.Vibebox.MediaControls.supported() ? 'API có — hiện thông báo tùy trình duyệt' : 'Không hỗ trợ ở đây',
        !!(window.Vibebox.MediaControls && window.Vibebox.MediaControls.supported())],
      ['Chọn file cục bộ', window.URL && URL.createObjectURL ? 'Có' : 'Không', !!(window.URL && URL.createObjectURL)],
    ];
    $('caps').innerHTML = rows.map(([k, v, ok]) =>
      '<li><span>' + k + '</span><b class="' + (ok ? 'ok' : 'warn') + '">' + v + '</b></li>').join('');
  }

  // ---------- Khởi động ----------
  UI.initTabs((tab) => {
    currentTab = tab;
    if (tab === 'eq') requestAnimationFrame(drawEq);
    if (tab === 'settings') renderCapabilities();
    updateSpectrum();
  });

  engine.on('status', refreshStatus);
  document.addEventListener('visibilitychange', updateSpectrum);
  window.addEventListener('resize', () => { if (currentTab === 'eq') drawEq(); });

  vol.value = engine.volume; $('volLabel').textContent = Math.round(engine.volume * 100) + '%';
  $('headroomToggle').checked = engine.headroom;
  $('eqToggle').checked = engine.enabled;
  bandsEl.classList.toggle('disabled', !engine.enabled);

  if (!engine.supported) {
    $('unsupported').hidden = false;
    $('unsupportedMsg').textContent = engine.error || '';
    document.querySelectorAll('button:not(.nav-btn), input').forEach((el) => { el.disabled = true; });
  } else {
    spectrum = new UI.Spectrum($('spectrum'), engine.analyser);
  }

  rebuildBands();
  renderQueue();
  refreshStatus();
  renderCapabilities();

  // Thông báo điều khiển (thanh thông báo / màn hình khóa / tai nghe)
  if (audio && window.Vibebox.MediaControls) {
    const mc = window.Vibebox.MediaControls.attach({
      audio: audio,
      getTitle: () => (state.index >= 0 ? state.queue[state.index].name : 'VIBEBOX'),
      onPlay: () => play(),
      onPause: () => engine.pause(),
      onPrev: () => $('prevBtn').click(),
      onNext: () => $('nextBtn').click(),
      onSeekTo: (t) => engine.seek(t),
    });
    void mc;
  }

})();
