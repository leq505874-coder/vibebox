/*
 * VIBEBOX — UI helpers
 * Chỉ vẽ/cập nhật DOM; không chứa logic âm thanh hay lưu trữ.
 */
(function (global) {
  'use strict';

  const { GAIN_MIN, GAIN_MAX } = global.Vibebox;

  const formatDb = (v) => (v > 0 ? '+' : '') + v.toFixed(1);
  const formatFreq = (f) => (f >= 1000 ? (f / 1000).toFixed(f % 1000 === 0 ? 0 : 1) + 'k' : String(f));
  const formatTime = (s) => {
    if (!isFinite(s) || s < 0) return '0:00';
    const m = Math.floor(s / 60), r = Math.floor(s % 60);
    return m + ':' + String(r).padStart(2, '0');
  };

  const STATUS_TEXT = { active: 'Active', inactive: 'Inactive', unsupported: 'Unsupported' };

  function setStatus(el, status) {
    el.className = 'chip chip-' + status.state;
    el.querySelector('.chip-label').textContent = STATUS_TEXT[status.state];
    el.title = status.reason;
  }

  function initTabs(onChange) {
    const buttons = document.querySelectorAll('.nav-btn');
    buttons.forEach((btn) => btn.addEventListener('click', () => {
      const tab = btn.dataset.tab;
      buttons.forEach((b) => { b.classList.toggle('active', b === btn); b.setAttribute('aria-selected', b === btn); });
      document.querySelectorAll('.tab').forEach((s) => s.classList.toggle('active', s.id === 'tab-' + tab));
      if (onChange) onChange(tab);
    }));
  }

  /** Dựng các cột slider cho từng băng. */
  function renderBands(container, freqs, gains, handlers) {
    container.innerHTML = '';
    container.style.setProperty('--bands', freqs.length);
    freqs.forEach((f, i) => {
      const col = document.createElement('div');
      col.className = 'band';
      col.innerHTML =
        '<button class="band-db" type="button" title="Chạm để đặt lại 0 dB"></button>' +
        '<div class="slider-wrap"><input type="range" aria-label="Gain ' + formatFreq(f) + ' Hz"></div>' +
        '<span class="band-hz">' + formatFreq(f) + '</span>';
      const input = col.querySelector('input');
      input.min = GAIN_MIN; input.max = GAIN_MAX; input.step = 0.5;
      input.value = gains[i];
      const label = col.querySelector('.band-db');
      label.textContent = formatDb(gains[i]);
      input.addEventListener('input', () => handlers.onInput(i, parseFloat(input.value)));
      label.addEventListener('click', () => handlers.onInput(i, 0, true));
      container.appendChild(col);
    });
  }

  function updateBandValues(container, gains) {
    container.querySelectorAll('.band').forEach((col, i) => {
      col.querySelector('input').value = gains[i];
      const label = col.querySelector('.band-db');
      label.textContent = formatDb(gains[i]);
      label.classList.toggle('boost', gains[i] > 0);
      label.classList.toggle('cut', gains[i] < 0);
    });
  }

  function fitCanvas(canvas) {
    const dpr = Math.min(global.devicePixelRatio || 1, 2);
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    }
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return { ctx, w, h };
  }

  /** Vẽ đường cong đáp ứng tần số thật (từ BiquadFilterNode) trên thang log. */
  function drawCurve(canvas, resp, freqs, enabled) {
    const { ctx, w, h } = fitCanvas(canvas);
    ctx.clearRect(0, 0, w, h);
    const xOf = (hz) => (Math.log10(hz / 20) / 3) * w;
    const yOf = (db) => h / 2 - (db / 15) * (h / 2 - 6);

    ctx.lineWidth = 1;
    ctx.font = '10px system-ui, sans-serif';
    ctx.fillStyle = 'rgba(255,255,255,.35)';
    ctx.strokeStyle = 'rgba(255,255,255,.07)';
    [-12, -6, 0, 6, 12].forEach((db) => {
      ctx.beginPath(); ctx.moveTo(0, yOf(db)); ctx.lineTo(w, yOf(db)); ctx.stroke();
      ctx.fillText((db > 0 ? '+' : '') + db, 4, yOf(db) - 3);
    });
    [100, 1000, 10000].forEach((hz) => {
      ctx.beginPath(); ctx.moveTo(xOf(hz), 0); ctx.lineTo(xOf(hz), h); ctx.stroke();
      ctx.fillText(formatFreq(hz), xOf(hz) + 3, h - 4);
    });

    const grad = ctx.createLinearGradient(0, 0, w, 0);
    grad.addColorStop(0, '#8b5cf6'); grad.addColorStop(1, '#22d3ee');
    ctx.globalAlpha = enabled ? 1 : 0.35;

    ctx.beginPath();
    resp.hz.forEach((hz, i) => {
      const x = xOf(hz), y = yOf(Math.max(-15, Math.min(15, resp.db[i])));
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.lineWidth = 2.5; ctx.strokeStyle = grad; ctx.stroke();
    ctx.lineTo(w, h / 2); ctx.lineTo(0, h / 2); ctx.closePath();
    ctx.globalAlpha = enabled ? 0.14 : 0.05; ctx.fillStyle = grad; ctx.fill();
    ctx.globalAlpha = 1;
  }

  /** Phổ thời gian thực (AnalyserNode) — chỉ chạy khi tab Now Playing hiển thị và đang phát. */
  class Spectrum {
    constructor(canvas, analyser) {
      this.canvas = canvas; this.analyser = analyser; this.raf = 0;
      this.data = new Uint8Array(analyser.frequencyBinCount);
    }
    start() { if (!this.raf) this._loop(); }
    stop() { cancelAnimationFrame(this.raf); this.raf = 0; this._clear(); }
    _clear() { const { ctx, w, h } = fitCanvas(this.canvas); ctx.clearRect(0, 0, w, h); }
    _loop() {
      this.raf = requestAnimationFrame(() => this._loop());
      const { ctx, w, h } = fitCanvas(this.canvas);
      this.analyser.getByteFrequencyData(this.data);
      ctx.clearRect(0, 0, w, h);
      const bars = 32, usable = Math.floor(this.data.length * 0.7);
      const bw = w / bars;
      const grad = ctx.createLinearGradient(0, h, 0, 0);
      grad.addColorStop(0, '#8b5cf6'); grad.addColorStop(1, '#22d3ee');
      ctx.fillStyle = grad;
      for (let i = 0; i < bars; i++) {
        const idx = Math.floor(Math.pow(i / bars, 1.6) * usable);
        const v = this.data[idx] / 255;
        const bh = Math.max(2, v * h * 0.95);
        ctx.fillRect(i * bw + 1.5, h - bh, bw - 3, bh);
      }
    }
  }

  function renderPresetList(container, presets, activeId, handlers) {
    container.innerHTML = '';
    if (!presets.length) {
      container.innerHTML = '<p class="muted">Chưa có preset nào.</p>';
      return;
    }
    presets.forEach((p) => {
      const card = document.createElement('div');
      card.className = 'preset-card' + (p.id === activeId ? ' selected' : '');
      card.innerHTML =
        '<div class="preset-info"><strong></strong><span class="muted"></span></div>' +
        '<div class="preset-actions"></div>';
      card.querySelector('strong').textContent = p.name;
      card.querySelector('.muted').textContent = p.desc || '';
      const actions = card.querySelector('.preset-actions');
      const apply = document.createElement('button');
      apply.className = 'btn small'; apply.textContent = p.id === activeId ? 'Đang dùng' : 'Áp dụng';
      apply.addEventListener('click', () => handlers.onApply(p.id));
      actions.appendChild(apply);
      if (!p.builtin) {
        const del = document.createElement('button');
        del.className = 'btn small ghost danger'; del.textContent = 'Xóa';
        del.setAttribute('aria-label', 'Xóa preset ' + p.name);
        del.addEventListener('click', () => handlers.onDelete(p.id));
        actions.appendChild(del);
      }
      container.appendChild(card);
    });
  }

  let toastTimer = 0;
  function toast(msg) {
    const el = document.getElementById('toast');
    el.textContent = msg; el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 2800);
  }

  function renderSelfTest(container, rows) {
    let html = '<table class="test-table"><thead><tr><th>Băng</th><th>Cài đặt</th><th>Lý thuyết</th><th>Đo được</th></tr></thead><tbody>';
    let worst = 0;
    rows.forEach((r) => {
      const diff = Math.abs(r.measuredDb - r.theoryDb);
      worst = Math.max(worst, diff);
      html += '<tr><td>' + formatFreq(r.freq) + ' Hz</td><td>' + formatDb(r.setDb) + '</td><td>' +
        formatDb(r.theoryDb) + '</td><td>' + formatDb(r.measuredDb) + '</td></tr>';
    });
    html += '</tbody></table>';
    const ok = worst < 0.5;
    html += '<p class="' + (ok ? 'ok' : 'warn') + '">' + (ok
      ? 'Đạt: giá trị đo lệch lý thuyết tối đa ' + worst.toFixed(2) + ' dB. Bộ lọc đang thực sự thay đổi tín hiệu.'
      : 'Lệch ' + worst.toFixed(2) + ' dB so với lý thuyết — cần kiểm tra lại.') + '</p>';
    container.innerHTML = html;
  }

  global.Vibebox = Object.assign(global.Vibebox || {}, {
    UI: { formatDb, formatFreq, formatTime, setStatus, initTabs, renderBands, updateBandValues,
      drawCurve, Spectrum, renderPresetList, toast, renderSelfTest },
  });
})(window);
