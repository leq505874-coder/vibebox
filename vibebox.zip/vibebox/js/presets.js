/*
 * VIBEBOX — Preset manager
 * Preset được mô tả bằng "điểm cong" [tần số Hz, dB], nên áp dụng được cho mọi số băng
 * (nội suy theo trục log-tần số). Preset người dùng lưu thêm gains + bandCount để khôi phục chính xác.
 * Lưu trữ: localStorage (nếu bị chặn thì chạy ở chế độ chỉ-trong-phiên và báo rõ cho người dùng).
 */
(function (global) {
  'use strict';

  const KEY_PRESETS = 'vibebox.presets.v1';
  const KEY_STATE = 'vibebox.state.v1';
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  const BUILTIN_PRESETS = [
    {
      id: 'balanced', name: 'Balanced', builtin: true,
      desc: 'Phẳng, không tô màu — điểm xuất phát để so sánh.',
      points: [[32, 0], [16000, 0]],
    },
    {
      id: 'astra-vocal', name: 'ASTRA Vocal', builtin: true,
      desc: 'Làm rõ giọng hát: giảm bùn 200–500 Hz, nâng 2–4 kHz, thêm chút không khí.',
      points: [[32, -2], [160, -1.5], [400, -2], [1000, 1], [2500, 3.5], [4000, 3], [8000, 1.5], [16000, 1]],
    },
    {
      id: 'warm-ballad', name: 'Warm Ballad', builtin: true,
      desc: 'Ấm và mượt: dày thân 100–250 Hz, dịu dải chói 3–8 kHz.',
      points: [[32, 1], [100, 3], [250, 2.5], [1000, 0], [3000, -1.5], [6000, -2.5], [10000, -2], [16000, -1.5]],
    },
    {
      id: 'bass-control', name: 'Bass Control', builtin: true,
      desc: 'Kiểm soát trầm: siết sub-bass quá đà, giữ độ chắc ở 100–200 Hz, sáng nhẹ phần trên.',
      points: [[32, -5], [60, -4], [120, -1], [200, 0.5], [500, 0], [4000, 1], [10000, 1.5], [16000, 1.5]],
    },
  ];

  /** Nội suy tuyến tính theo log(f); làm tròn 0.5 dB, giới hạn ±12 dB. */
  function interpolate(points, freqs) {
    const p = points.slice().sort((a, b) => a[0] - b[0]);
    return freqs.map((f) => {
      let g;
      if (f <= p[0][0]) g = p[0][1];
      else if (f >= p[p.length - 1][0]) g = p[p.length - 1][1];
      else {
        for (let i = 0; i < p.length - 1; i++) {
          if (f >= p[i][0] && f <= p[i + 1][0]) {
            const t = (Math.log(f) - Math.log(p[i][0])) / (Math.log(p[i + 1][0]) - Math.log(p[i][0]));
            g = p[i][1] + (p[i + 1][1] - p[i][1]) * t;
            break;
          }
        }
      }
      return clamp(Math.round(g * 2) / 2, -12, 12);
    });
  }

  /** Gain cho bộ tần số freqs: dùng đúng gains đã lưu nếu cùng số băng, ngược lại nội suy. */
  function presetGains(preset, freqs) {
    if (preset.gains && preset.bandCount === freqs.length) return preset.gains.slice();
    return interpolate(preset.points, freqs);
  }

  class PresetStore {
    constructor(storage) {
      this.storage = storage !== undefined ? storage : this._defaultStorage();
      this.available = this._probe();
      this.user = this._read(KEY_PRESETS, []);
      if (!Array.isArray(this.user)) this.user = [];
    }

    _defaultStorage() {
      try { return global.localStorage; } catch (e) { return null; }
    }

    _probe() {
      if (!this.storage) return false;
      try {
        this.storage.setItem('vibebox.__probe', '1');
        this.storage.removeItem('vibebox.__probe');
        return true;
      } catch (e) { return false; }
    }

    _read(key, fallback) {
      if (!this.available) return fallback;
      try {
        const raw = this.storage.getItem(key);
        return raw ? JSON.parse(raw) : fallback;
      } catch (e) { return fallback; }
    }

    _write(key, value) {
      if (!this.available) return false;
      try { this.storage.setItem(key, JSON.stringify(value)); return true; } catch (e) { return false; }
    }

    all() { return BUILTIN_PRESETS.concat(this.user); }
    get(id) { return this.all().find((p) => p.id === id) || null; }

    /** Lưu preset người dùng; trùng tên (không phân biệt hoa thường) thì ghi đè. */
    saveUser({ name, freqs, gains }) {
      name = String(name || '').trim().slice(0, 32);
      if (!name) throw new Error('Hãy đặt tên cho preset.');
      if (BUILTIN_PRESETS.some((p) => p.name.toLowerCase() === name.toLowerCase())) {
        throw new Error('Tên này trùng preset có sẵn, hãy chọn tên khác.');
      }
      const existing = this.user.find((p) => p.name.toLowerCase() === name.toLowerCase());
      const preset = {
        id: existing ? existing.id : 'user-' + Date.now().toString(36),
        name, builtin: false,
        desc: gains.length + ' băng · do bạn lưu',
        bandCount: gains.length,
        gains: gains.slice(),
        points: freqs.map((f, i) => [f, gains[i]]),
      };
      if (existing) this.user[this.user.indexOf(existing)] = preset; else this.user.push(preset);
      const ok = this._write(KEY_PRESETS, this.user);
      return { preset, persisted: ok };
    }

    remove(id) {
      this.user = this.user.filter((p) => p.id !== id);
      return this._write(KEY_PRESETS, this.user);
    }

    loadState() { return this._read(KEY_STATE, null); }
    saveState(state) { return this._write(KEY_STATE, state); }

    clearAll() {
      this.user = [];
      if (!this.available) return;
      try { this.storage.removeItem(KEY_PRESETS); this.storage.removeItem(KEY_STATE); } catch (e) { /* bỏ qua */ }
    }
  }

  global.Vibebox = Object.assign(global.Vibebox || {}, {
    PresetStore, BUILTIN_PRESETS, interpolate, presetGains,
  });
})(typeof window !== 'undefined' ? window : globalThis);
