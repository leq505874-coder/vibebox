// Chạy: node tests/engine.test.js
// Không có trình duyệt trong môi trường này, nên test dùng một AudioContext GIẢ LẬP với biquad
// theo công thức RBJ (đúng như spec Web Audio). Nó kiểm tra logic của VIBEBOX (nối đồ thị, bypass,
// headroom, self-test, preset, lưu trữ), KHÔNG thay thế việc nghe thử trên thiết bị thật.
const assert = require('assert');

class Param { constructor(v) { this.value = v; } setTargetAtTime(v) { this.value = v; } }
class Node {
  constructor() { this.out = new Set(); }
  connect(n) { this.out.add(n); return n; }
  disconnect() { this.out.clear(); }
}
class Gain extends Node { constructor() { super(); this.gain = new Param(1); } }
class Analyser extends Node { constructor() { super(); this.frequencyBinCount = 256; } }
class BufSrc extends Node { start() {} stop() {} }
class Biquad extends Node {
  constructor(sr) { super(); this.sr = sr; this.type = 'peaking'; this.frequency = new Param(350); this.Q = new Param(1); this.gain = new Param(0); }
  coeffs() {
    const f0 = this.frequency.value, Q = this.Q.value, A = Math.pow(10, this.gain.value / 40);
    const w = 2 * Math.PI * f0 / this.sr, cw = Math.cos(w), sw = Math.sin(w);
    let b0, b1, b2, a0, a1, a2;
    if (this.type === 'peaking') {
      const al = sw / (2 * Q);
      b0 = 1 + al * A; b1 = -2 * cw; b2 = 1 - al * A; a0 = 1 + al / A; a1 = -2 * cw; a2 = 1 - al / A;
    } else {
      const al = sw / 2 * Math.sqrt(2), s = 2 * Math.sqrt(A) * al; // S=1
      if (this.type === 'lowshelf') {
        b0 = A * ((A + 1) - (A - 1) * cw + s); b1 = 2 * A * ((A - 1) - (A + 1) * cw); b2 = A * ((A + 1) - (A - 1) * cw - s);
        a0 = (A + 1) + (A - 1) * cw + s; a1 = -2 * ((A - 1) + (A + 1) * cw); a2 = (A + 1) + (A - 1) * cw - s;
      } else {
        b0 = A * ((A + 1) + (A - 1) * cw + s); b1 = -2 * A * ((A - 1) + (A + 1) * cw); b2 = A * ((A + 1) + (A - 1) * cw - s);
        a0 = (A + 1) - (A - 1) * cw + s; a1 = 2 * ((A - 1) - (A + 1) * cw); a2 = (A + 1) - (A - 1) * cw - s;
      }
    }
    return [b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0];
  }
  getFrequencyResponse(hz, mag, ph) {
    const [b0, b1, b2, a1, a2] = this.coeffs();
    hz.forEach((f, i) => {
      const w = 2 * Math.PI * f / this.sr, c1 = Math.cos(w), s1 = Math.sin(w), c2 = Math.cos(2 * w), s2 = Math.sin(2 * w);
      const nr = b0 + b1 * c1 + b2 * c2, ni = -(b1 * s1 + b2 * s2), dr = 1 + a1 * c1 + a2 * c2, di = -(a1 * s1 + a2 * s2);
      mag[i] = Math.hypot(nr, ni) / Math.hypot(dr, di); ph[i] = 0;
    });
  }
  process(x) {
    const [b0, b1, b2, a1, a2] = this.coeffs(); const y = new Float32Array(x.length);
    let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
    for (let i = 0; i < x.length; i++) {
      const v = b0 * x[i] + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2; y[i] = v; x2 = x1; x1 = x[i]; y2 = y1; y1 = v;
    }
    return y;
  }
}
class MockCtx {
  constructor() { this.sampleRate = 44100; this.state = 'suspended'; this.currentTime = 0; this.destination = new Node(); }
  addEventListener() {}
  resume() { this.state = 'running'; return Promise.resolve(); }
  createGain() { return new Gain(); }
  createAnalyser() { return new Analyser(); }
  createBiquadFilter() { return new Biquad(this.sampleRate); }
  createMediaElementSource() { return new Node(); }
  createBuffer(c, l) { const d = new Float32Array(l); return { getChannelData: () => d }; }
  createBufferSource() { return new BufSrc(); }
}
class MockOffline extends MockCtx {
  constructor(c, len, sr) { super(); this.len = len; this.sampleRate = sr; this.chain = []; this.src = null; }
  createBufferSource() { const s = new BufSrc(); this.src = s; return s; }
  async startRendering() {
    let sig = this.src.buffer.getChannelData(0), n = this.src.out.values().next().value;
    while (n instanceof Biquad) { sig = n.process(sig); n = n.out.values().next().value; }
    return { getChannelData: () => sig };
  }
}
class FakeAudio { constructor() { this.paused = true; this.ended = false; this.listeners = {}; }
  addEventListener(e, f) { (this.listeners[e] = this.listeners[e] || []).push(f); }
  load() {} play() { this.paused = false; return Promise.resolve(); } pause() { this.paused = true; } }

global.window = global;
global.AudioContext = MockCtx; global.OfflineAudioContext = MockOffline; global.Audio = FakeAudio;
require('../js/audio-engine.js'); require('../js/presets.js');
const { AudioEngine, makeFreqs, BUILTIN_PRESETS, PresetStore, interpolate, presetGains } = global.Vibebox;

let passed = 0;
const t = async (name, fn) => { await fn(); passed++; console.log('  ✓', name); };

(async () => {
  await t('makeFreqs: số băng linh hoạt, tăng dần, 32 Hz..16 kHz', () => {
    [3, 5, 8, 10, 15].forEach((n) => {
      const f = makeFreqs(n);
      assert.strictEqual(f.length, n); assert.strictEqual(f[0], 32); assert.strictEqual(f[n - 1], 16000);
      for (let i = 1; i < n; i++) assert(f[i] > f[i - 1]);
    });
    assert.strictEqual(makeFreqs(99).length, 15); assert.strictEqual(makeFreqs(1).length, 3);
  });

  await t('interpolate: giữ đúng giá trị tại điểm và nằm trong ±12 dB', () => {
    const pts = [[100, 3], [1000, -3]];
    assert.deepStrictEqual(interpolate(pts, [100, 1000]), [3, -3]);
    assert.deepStrictEqual(interpolate(pts, [20, 20000]), [3, -3]);
    interpolate([[32, 40], [16000, -40]], makeFreqs(10)).forEach((g) => assert(g >= -12 && g <= 12));
  });

  await t('preset dựng sẵn: đủ 4 preset ASTRA Vocal/Warm Ballad/Balanced/Bass Control; Balanced phẳng', () => {
    assert.deepStrictEqual(BUILTIN_PRESETS.map((p) => p.name), ['Balanced', 'ASTRA Vocal', 'Warm Ballad', 'Bass Control']);
    assert(presetGains(BUILTIN_PRESETS[0], makeFreqs(10)).every((g) => g === 0));
    const vocal = presetGains(BUILTIN_PRESETS[1], makeFreqs(10));
    assert(Math.max(...vocal) >= 3, 'Vocal phải nâng dải trung-cao');
  });

  await t('PresetStore: lưu, tải lại sau "reload", ghi đè cùng tên, xóa, chặn trùng preset có sẵn', () => {
    const mem = {}; const storage = { getItem: (k) => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: (k) => { delete mem[k]; } };
    const a = new PresetStore(storage); assert(a.available);
    const freqs = makeFreqs(8), gains = [1, 2, 3, 0, -1, -2, 0.5, 4];
    const { preset } = a.saveUser({ name: 'My Mix', freqs, gains });
    const b = new PresetStore(storage); // mô phỏng tải lại trang
    assert.deepStrictEqual(presetGains(b.get(preset.id), freqs), gains);
    assert.strictEqual(presetGains(b.get(preset.id), makeFreqs(10)).length, 10);
    a.saveUser({ name: 'my mix', freqs, gains: gains.map(() => 0) }); assert.strictEqual(a.user.length, 1);
    assert.throws(() => a.saveUser({ name: 'balanced', freqs, gains }));
    assert.throws(() => a.saveUser({ name: '  ', freqs, gains }));
    a.remove(preset.id); assert.strictEqual(new PresetStore(storage).user.length, 0);
    a.saveState({ enabled: false, gains }); assert.strictEqual(new PresetStore(storage).loadState().enabled, false);
  });

  await t('PresetStore: storage bị chặn -> available=false, không ném lỗi', () => {
    const s = new PresetStore({ getItem() { throw new Error('x'); }, setItem() { throw new Error('x'); }, removeItem() {} });
    assert.strictEqual(s.available, false);
    assert.strictEqual(s.saveUser({ name: 'A', freqs: [32, 16000], gains: [1, 2] }).persisted, false);
  });

  await t('Engine: không có Web Audio -> status Unsupported', () => {
    const keep = global.AudioContext; global.AudioContext = undefined;
    const e = new AudioEngine(); assert.strictEqual(e.supported, false);
    assert.strictEqual(e.status().state, 'unsupported'); assert.strictEqual(e.init(), false);
    global.AudioContext = keep;
  });

  await t('Engine: đồ thị nối đúng (EQ bật) và bypass khi tắt', () => {
    const e = new AudioEngine(); e.init();
    assert.strictEqual(e.filters.length, 10);
    assert(e.input.out.has(e.filters[0])); assert(e.filters[9].out.has(e.preamp));
    e.setEnabled(false);
    assert(e.input.out.has(e.preamp)); assert(!e.input.out.has(e.filters[0]));
    e.setEnabled(true); assert(e.input.out.has(e.filters[0]));
  });

  await t('Engine: đổi số băng dựng lại chuỗi lọc; trạng thái Inactive/Active', async () => {
    const e = new AudioEngine(); e.init(); e.setBandCount(15); assert.strictEqual(e.filters.length, 15);
    assert(e.input.out.has(e.filters[0])); assert.strictEqual(e.status().state, 'inactive');
    e.audio.src = 'x'; await e.play(); assert.strictEqual(e.status().state, 'active');
    e.setEnabled(false); assert.strictEqual(e.status().state, 'inactive');
  });

  await t('Engine: đường cong đáp ứng phản ánh gain; headroom hạ preamp bằng mức boost lớn nhất', () => {
    const e = new AudioEngine(); e.init(); e.setGain(5, 12);
    const r = e.getResponse(400); const peak = Math.max(...r.db);
    assert(peak > 9 && peak <= 12.5, 'đỉnh ' + peak);
    assert(Math.abs(20 * Math.log10(e.preamp.gain.value) + peak) < 0.3);
    e.setHeadroom(false); assert.strictEqual(e.preamp.gain.value, 1);
    e.setEnabled(false); assert(e.getResponse(50).db.every((d) => d === 0));
  });

  await t('Engine: selfTest đo được mức đúng với cài đặt (độc lập với đường cong lý thuyết)', async () => {
    const e = new AudioEngine(); e.init();
    e.setGains([-4, -2, 0, 3, 6, 9, 3, 0, -3, 5]);
    const rows = await e.selfTest();
    rows.forEach((r) => assert(Math.abs(r.measuredDb - r.theoryDb) < 0.3, r.freq + ' Hz: đo ' + r.measuredDb.toFixed(2) + ' vs ' + r.theoryDb.toFixed(2)));
    assert(rows[5].measuredDb > 6, 'băng +9 dB phải tăng rõ rệt');
    assert(rows[0].measuredDb < -2, 'băng -4 dB phải giảm');
    e.reset(); (await e.selfTest()).forEach((r) => assert(Math.abs(r.measuredDb) < 0.1));
  });

  console.log('\n' + passed + ' test đạt');
})().catch((err) => { console.error('FAIL:', err.message); process.exit(1); });
