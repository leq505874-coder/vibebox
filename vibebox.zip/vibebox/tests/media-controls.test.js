// node tests/media-controls.test.js — kiểm tra logic Media Session với navigator giả lập.
const assert = require('assert');
global.MediaMetadata = class { constructor(o) { Object.assign(this, o); } };
require('../js/media-controls.js');
const MC = globalThis.Vibebox.MediaControls;

function fakeAudio() {
  const l = {};
  return { paused: true, duration: 200, currentTime: 12, playbackRate: 1,
    addEventListener(e, f) { (l[e] = l[e] || []).push(f); }, fire(e) { (l[e] || []).forEach((f) => f()); } };
}
function fakeNav() {
  const handlers = {}; let pos = null, n = 0;
  return { handlers, get pos() { return pos; }, get calls() { return n; },
    mediaSession: { metadata: null, playbackState: 'none',
      setActionHandler(n, f) { handlers[n] = f; }, setPositionState(p) { pos = p; n++; } } };
}

assert.strictEqual(MC.supported({}), false);
assert.strictEqual(MC.attach({ audio: fakeAudio() }, {}).supported, false);

const nav = fakeNav(), audio = fakeAudio(), calls = [];
let title = 'Bai A';
const r = MC.attach({ audio, getTitle: () => title,
  onPlay: () => calls.push('play'), onPause: () => calls.push('pause'),
  onPrev: () => calls.push('prev'), onNext: () => calls.push('next'), onSeekTo: (t) => calls.push('seek:' + t) }, nav);
assert(r.supported);
['play', 'pause', 'previoustrack', 'nexttrack', 'seekto'].forEach((n) => assert(nav.handlers[n], 'thiếu ' + n));
assert.strictEqual(nav.mediaSession.metadata.title, 'Bai A');
assert.strictEqual(nav.mediaSession.playbackState, 'paused');

nav.handlers.play(); nav.handlers.pause(); nav.handlers.previoustrack(); nav.handlers.nexttrack(); nav.handlers.seekto({ seekTime: 42 });
assert.deepStrictEqual(calls, ['play', 'pause', 'prev', 'next', 'seek:42']);

title = 'Bai B'; audio.paused = false; audio.fire('loadstart'); audio.fire('play');
assert.strictEqual(nav.mediaSession.metadata.title, 'Bai B');
assert.strictEqual(nav.mediaSession.playbackState, 'playing');
assert.deepStrictEqual(nav.pos, { duration: 200, playbackRate: 1, position: 12 });

nav.handlers.seekforward({ seekOffset: 30 }); nav.handlers.seekbackward({});
assert.strictEqual(calls[5], 'seek:42'); assert.strictEqual(calls[6], 'seek:2');

const before = nav.calls; audio.duration = NaN; audio.fire('seeked'); assert.strictEqual(nav.calls, before, 'không đặt vị trí khi duration không hợp lệ');
console.log('media-controls: đạt');
