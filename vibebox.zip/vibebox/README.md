# VIBEBOX Music Studio Pocket — ASTRA UI

Trình phát nhạc + Equalizer chạy trên web (HTML/CSS/JS thuần, không build, không phụ thuộc).
EQ xử lý âm thanh **thật** bằng Web Audio API cho âm thanh do chính ứng dụng phát.

## Chạy thử
- Mở `index.html` trực tiếp bằng Chrome/Firefox (không cần server), hoặc dùng `vibebox-standalone.html` (1 file).
- Hoặc `python3 -m http.server` rồi mở `http://localhost:8000`.
- Bấm **Chọn file âm thanh**, hoặc vào **Settings → Phát nhiễu hồng thử EQ** để nghe EQ không cần file.

## Cấu trúc
| File | Vai trò |
|---|---|
| `js/audio-engine.js` | Đồ thị Web Audio, chuỗi biquad, bypass, headroom, nhiễu hồng, self-test. Không đụng DOM. |
| `js/presets.js` | Preset dựng sẵn, nội suy theo số băng, lưu/khôi phục (localStorage). Không đụng DOM/audio. |
| `js/ui.js` | Hàm vẽ DOM/canvas (slider, đường cong, phổ, danh sách preset). |
| `js/app.js` | Controller nối 3 phần trên. |
| `tests/engine.test.js` | `node tests/engine.test.js` — test logic với AudioContext giả lập (biquad RBJ). |

## Đồ thị âm thanh
`<audio>` / nhiễu hồng → input → [biquad × N] → preamp → analyser → master (âm lượng) → loa
Băng đầu = lowshelf, băng cuối = highshelf, các băng giữa = peaking. 5/8/10/15 băng, 32 Hz–16 kHz, ±12 dB.

## Kiểm tra EQ có tác dụng thật
Settings → **Chạy kiểm tra**: render offline sóng sin ở tâm mỗi băng qua đúng cấu hình EQ, đo RMS vào/ra (dB) và so với đáp ứng lý thuyết.

## Phạm vi — nói rõ
- Có: EQ cho file/nhiễu do VIBEBOX phát.
- **Không**: EQ cho Spotify, YouTube hay âm thanh hệ thống Android. Web app không thể chèn vào luồng của app khác.

## Lên APK Android native
1. Tạo project Kotlin + Jetpack Compose; chuyển 4 màn hình (Now Playing/EQ/Presets/Settings) từ `index.html`.
2. Phát nhạc: Media3 ExoPlayer + `MediaSessionService` (phát nền, điều khiển khóa màn hình).
3. EQ cho nhạc của app: gắn `android.media.audiofx.Equalizer` (+ `LoudnessEnhancer`) vào `audioSessionId` của ExoPlayer; hoặc tự chạy biquad (cùng công thức RBJ) qua `AudioProcessor` của Media3 để giống hệt bản web.
4. EQ toàn hệ thống: gắn effect vào audio session global (session 0) đã bị Android hạn chế/loại bỏ ở nhiều máy — cần thử trên từng thiết bị; cách đúng là `ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION` để các app phát nhạc tự gắn EQ của bạn. Phải kiểm chứng trên máy thật trước khi tuyên bố hỗ trợ.
5. Lưu preset: DataStore/Room, giữ cùng định dạng `{name, bandCount, gains, points}`.
6. Dùng `makeFreqs`, `bandQ`, `interpolate` làm thông số chuẩn để hai nền tảng cho cùng kết quả.

## Quy trình phát triển (GitHub)
1. Đưa thư mục này lên một repo GitHub, nhánh `main`.
2. Bật **Settings → Pages → Source: GitHub Actions** (một lần).
3. Mỗi lần push/PR, `.github/workflows/ci.yml` chạy:
   - `node --check` cho mọi file trong `js/`;
   - `node tests/engine.test.js` (logic engine, preset, lưu trữ).
4. Khi push vào `main` và test đạt, workflow tự đưa `index.html`, `css/`, `js/` lên GitHub Pages để mở trên điện thoại bằng link HTTPS.
5. Chạy local trước khi push: `node tests/engine.test.js`.

Lưu ý: test dùng AudioContext giả lập nên không thay thế việc nghe thử trên máy thật. Sau mỗi thay đổi về EQ, hãy chạy **Settings → Chạy kiểm tra** và nghe thử bằng nhiễu hồng.

## Cài như app / build APK
- **Cài từ trình duyệt (PWA):** mở link GitHub Pages bằng Chrome Android → menu ⋮ → *Cài đặt ứng dụng*.
- **APK:** workflow `.github/workflows/build-apk.yml` bọc web app bằng Capacitor và build `app-debug.apk`.
  Chạy ở tab Actions → *Build APK* → *Run workflow*, tải file trong mục Artifacts (`vibebox-apk`).
  Bản này là APK debug để thử; EQ vẫn là Web Audio trong WebView, chỉ tác động nhạc do VIBEBOX phát.

## Thông báo điều khiển (Media Session)
`js/media-controls.js` dùng Media Session API để hiện Play/Pause/Trước/Sau/tua trên thanh thông báo, màn hình khóa và tai nghe.
- Chạy trong Chrome Android và PWA đã cài (có test: `node tests/media-controls.test.js`).
- **APK Capacitor (WebView) không tự hiện thông báo media.** Muốn có trong APK cần plugin hoặc `MediaSessionService` native.
- Android có thể tạm dừng trang web khi tắt màn hình; phát nền ổn định cần service native.
